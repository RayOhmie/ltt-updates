# 绿色版增量更新：等主进程退出后对换 resources/app 与 app-next，再拉起 exe
$ErrorActionPreference = "SilentlyContinue"
$pidToWait = [int]$env:LTT_UPD_PID
$exe = $env:LTT_UPD_EXE
$app = $env:LTT_UPD_APP
$next = $env:LTT_UPD_NEXT
$bak = $env:LTT_UPD_BAK

if (-not $exe -or -not $app -or -not $next) { exit 1 }

try { Wait-Process -Id $pidToWait -Timeout 180 } catch {}
Start-Sleep -Milliseconds 900

function Start-App {
  if ($exe -and (Test-Path -LiteralPath $exe)) {
    Start-Process -FilePath $exe
  }
}

for ($i = 0; $i -lt 20; $i++) {
  try {
    if (Test-Path -LiteralPath $bak) {
      Remove-Item -LiteralPath $bak -Recurse -Force
    }
    if (-not (Test-Path -LiteralPath $app)) { throw "missing app" }
    if (-not (Test-Path -LiteralPath $next)) { throw "missing next" }
    Rename-Item -LiteralPath $app -NewName (Split-Path -Leaf $bak)
    Rename-Item -LiteralPath $next -NewName (Split-Path -Leaf $app)
    Start-App
    exit 0
  } catch {
    Start-Sleep -Seconds 1
  }
}

if ((Test-Path -LiteralPath $bak) -and -not (Test-Path -LiteralPath $app)) {
  Rename-Item -LiteralPath $bak -NewName (Split-Path -Leaf $app)
}
Start-App
exit 1
