# Swap resources/app with app-next after the desktop process exits, then relaunch.
$ErrorActionPreference = "Stop"
$log = Join-Path $env:TEMP "ltt-update-swap.log"
function Log($m) {
  try {
    $t = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    Add-Content -LiteralPath $log -Value "$t $m" -Encoding UTF8
  } catch {}
}

Log "begin"
Log "pid=$($env:LTT_UPD_PID)"
Log "exe=$($env:LTT_UPD_EXE)"
Log "app=$($env:LTT_UPD_APP)"
Log "next=$($env:LTT_UPD_NEXT)"
Log "bak=$($env:LTT_UPD_BAK)"

$pidToWait = 0
[void][int]::TryParse($env:LTT_UPD_PID, [ref]$pidToWait)
$exe = $env:LTT_UPD_EXE
$app = $env:LTT_UPD_APP
$next = $env:LTT_UPD_NEXT
$bak = $env:LTT_UPD_BAK

if (-not $exe -or -not $app -or -not $next -or -not $bak) {
  Log "missing env"
  exit 1
}

function Get-AppProcs {
  Get-Process -ErrorAction SilentlyContinue | Where-Object {
    try {
      $p = $_.Path
      return $p -and ($p -ieq $exe)
    } catch {
      return $false
    }
  }
}

function Wait-AppExit {
  if ($pidToWait -gt 0) {
    try { Wait-Process -Id $pidToWait -Timeout 180 -ErrorAction SilentlyContinue } catch {}
    Log "main pid wait done"
  }
  $deadline = (Get-Date).AddSeconds(120)
  while ((Get-Date) -lt $deadline) {
    $alive = @(Get-AppProcs)
    if ($alive.Count -eq 0) { break }
    Log ("waiting " + (($alive | ForEach-Object { $_.Id }) -join ","))
    Start-Sleep -Milliseconds 400
  }
  Start-Sleep -Milliseconds 1500
}

function Start-App {
  Log "start $exe"
  if (Test-Path -LiteralPath $exe) {
    Start-Process -FilePath $exe
  } else {
    Log "exe missing"
  }
}

function Restore-App {
  if ((Test-Path -LiteralPath $bak) -and -not (Test-Path -LiteralPath $app)) {
    try {
      Rename-Item -LiteralPath $bak -NewName (Split-Path -Leaf $app) -ErrorAction Stop
      Log "restored bak"
    } catch {
      Log "restore fail $($_.Exception.Message)"
    }
  }
}

Wait-AppExit

$appName = Split-Path -Leaf $app
$bakName = Split-Path -Leaf $bak
$nextName = Split-Path -Leaf $next
Log "names app=$appName bak=$bakName next=$nextName"

for ($i = 0; $i -lt 60; $i++) {
  try {
    if (Test-Path -LiteralPath $bak) {
      Remove-Item -LiteralPath $bak -Recurse -Force -ErrorAction Stop
    }
    if (-not (Test-Path -LiteralPath $app)) { throw "missing app" }
    if (-not (Test-Path -LiteralPath $next)) { throw "missing next" }
    Rename-Item -LiteralPath $app -NewName $bakName -ErrorAction Stop
    Log "renamed app -> $bakName"
    try {
      Rename-Item -LiteralPath $next -NewName $appName -ErrorAction Stop
    } catch {
      Log "rename next fail $($_.Exception.Message)"
      Restore-App
      throw
    }
    Log "renamed next -> $appName"
    Start-App
    Log "ok"
    exit 0
  } catch {
    Log "retry $i $($_.Exception.Message)"
    Start-Sleep -Seconds 1
  }
}

Log "giveup"
Restore-App
Start-App
exit 1
