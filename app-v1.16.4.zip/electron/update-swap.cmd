@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LOG=%TEMP%\ltt-update-swap.log"
>>"%LOG%" echo ----- %DATE% %TIME% begin

if "%LTT_UPD_EXE%"=="" goto fallback_ps
if "%LTT_UPD_APP%"=="" goto fallback_ps
if "%LTT_UPD_NEXT%"=="" goto fallback_ps
if "%LTT_UPD_BAK%"=="" goto fallback_ps

set /a _w=0
:wait_pid
if "%LTT_UPD_PID%"=="" goto wait_exe
tasklist /FI "PID eq %LTT_UPD_PID%" 2>nul | find "%LTT_UPD_PID%" >nul
if errorlevel 1 goto wait_exe
ping -n 2 127.0.0.1 >nul
set /a _w+=1
if %_w% LSS 180 goto wait_pid

:wait_exe
for %%I in ("%LTT_UPD_EXE%") do set "EXENAME=%%~nxI"
set /a _w=0
:wait_exe_loop
if "%EXENAME%"=="" goto settle
tasklist /FI "IMAGENAME eq %EXENAME%" 2>nul | find /I "%EXENAME%" >nul
if errorlevel 1 goto settle
ping -n 2 127.0.0.1 >nul
set /a _w+=1
if %_w% LSS 120 goto wait_exe_loop

:settle
ping -n 3 127.0.0.1 >nul

set /a _i=0
:retry
set /a _i+=1
if exist "%LTT_UPD_BAK%" rmdir /s /q "%LTT_UPD_BAK%"
if not exist "%LTT_UPD_APP%" goto retry_wait
if not exist "%LTT_UPD_NEXT%" goto retry_wait
ren "%LTT_UPD_APP%" "app-bak"
if errorlevel 1 goto retry_wait
ren "%LTT_UPD_NEXT%" "app"
if errorlevel 1 (
  if exist "%LTT_UPD_BAK%" if not exist "%LTT_UPD_APP%" ren "%LTT_UPD_BAK%" "app"
  goto retry_wait
)
>>"%LOG%" echo swapped ok
start "" "%LTT_UPD_EXE%"
exit /b 0

:retry_wait
>>"%LOG%" echo retry %_i%
ping -n 2 127.0.0.1 >nul
if %_i% LSS 60 goto retry

:fallback_ps
>>"%LOG%" echo fallback powershell
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
"%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0ltt-update-swap.ps1"
exit /b %ERRORLEVEL%
