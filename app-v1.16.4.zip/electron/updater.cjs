// 绿色版增量更新：只替换 resources/app（渲染层 + 主进程脚本），不重下 Electron 运行库
const { app, ipcMain, net, BrowserWindow } = require("electron");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const { spawn, spawnSync } = require("child_process");

/** 独立公开更新仓（仅 app.zip + latest.json），禁止把更新发到源码仓。 */
const GH_UPDATE_REPO = "RayOhmie/ltt-updates";
const GITEE_UPDATE_REPO = "rayohmie/ltt-updates";
const FEED_URLS = [
  `https://gitee.com/${GITEE_UPDATE_REPO}/raw/main/latest.json`,
  `https://gitee.com/${GITEE_UPDATE_REPO}/raw/master/latest.json`,
  `https://cdn.jsdelivr.net/gh/${GH_UPDATE_REPO}@main/latest.json`,
  `https://fastly.jsdelivr.net/gh/${GH_UPDATE_REPO}@main/latest.json`,
  `https://raw.gitmirror.com/${GH_UPDATE_REPO}/main/latest.json`,
  `https://github.com/${GH_UPDATE_REPO}/releases/latest/download/latest.json`,
  `https://raw.githubusercontent.com/${GH_UPDATE_REPO}/main/latest.json`,
];

let state = {
  phase: "idle",
  current: "0.0.0",
  packaged: false,
};

function emit(patch) {
  state = { ...state, ...patch };
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) win.webContents.send("ltt:update", state);
  }
  return state;
}

function cmpVer(a, b) {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

function readLocalVersion() {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "package.json"), "utf8"));
    return String(pkg.version || "0.0.0");
  } catch {
    return "0.0.0";
  }
}

function canSwapApp() {
  if (process.platform !== "win32") return false;
  if (!app.isPackaged) return false;
  const appDir = path.join(process.resourcesPath, "app");
  return fs.existsSync(path.join(appDir, "package.json")) && fs.existsSync(path.join(appDir, "dist", "index.html"));
}

function swapPaths() {
  return {
    appDir: path.join(process.resourcesPath, "app"),
    nextDir: path.join(process.resourcesPath, "app-next"),
    bakDir: path.join(process.resourcesPath, "app-bak"),
    lockFile: path.join(process.resourcesPath, "ltt-swap.lock"),
    ps1: path.join(process.resourcesPath, "ltt-update-swap.ps1"),
    cmd: path.join(process.resourcesPath, "ltt-update-swap.cmd"),
  };
}

function nextDirReady(wantVer) {
  const { nextDir } = swapPaths();
  const pkgPath = path.join(nextDir, "package.json");
  const html = path.join(nextDir, "dist", "index.html");
  const mainJs = path.join(nextDir, "electron", "main.cjs");
  if (!fs.existsSync(pkgPath) || !fs.existsSync(html) || !fs.existsSync(mainJs)) return false;
  try {
    const v = String(JSON.parse(fs.readFileSync(pkgPath, "utf8")).version || "");
    if (wantVer) return v === String(wantVer);
    return cmpVer(v, readLocalVersion()) > 0;
  } catch {
    return false;
  }
}

function recentlyFailedSwap(lockFile) {
  try {
    if (!fs.existsSync(lockFile)) return false;
    return Date.now() - fs.statSync(lockFile).mtimeMs < 120000;
  } catch {
    return false;
  }
}

function writeUtf8Bom(src, dest) {
  const raw = fs.readFileSync(src);
  const hasBom = raw.length >= 3 && raw[0] === 0xef && raw[1] === 0xbb && raw[2] === 0xbf;
  fs.writeFileSync(dest, hasBom ? raw : Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), raw]));
}

function pickSwapSource(name) {
  const p = swapPaths();
  const fromNext = path.join(p.nextDir, "electron", name);
  if (fs.existsSync(fromNext)) return fromNext;
  return path.join(__dirname, name);
}

function swapEnv(p) {
  return {
    ...process.env,
    LTT_UPD_PID: String(process.pid),
    LTT_UPD_EXE: process.execPath,
    LTT_UPD_APP: p.appDir,
    LTT_UPD_NEXT: p.nextDir,
    LTT_UPD_BAK: p.bakDir,
    LTT_UPD_CWD: process.resourcesPath,
    LTT_SWAP_CMD: p.cmd,
  };
}

/** 用 start / Start-Process 拉起独立脚本，避免随 Electron 作业对象一起退出 */
function launchSwapAndQuit() {
  const p = swapPaths();
  writeUtf8Bom(pickSwapSource("update-swap.ps1"), p.ps1);
  const cmdBody = fs.readFileSync(pickSwapSource("update-swap.cmd"), "utf8").replace(/\r?\n/g, "\r\n");
  fs.writeFileSync(p.cmd, cmdBody);
  try {
    fs.writeFileSync(p.lockFile, String(Date.now()));
  } catch {
    /* ignore */
  }
  const env = swapEnv(p);
  const comspec = process.env.ComSpec || "cmd.exe";
  const quotedCmd = p.cmd.replace(/"/g, '""');
  const started = spawnSync(comspec, ["/d", "/s", "/c", `start "ltt-upd" /min "${quotedCmd}"`], {
    cwd: process.resourcesPath,
    env,
    windowsHide: true,
    windowsVerbatimArguments: true,
    stdio: "ignore",
    timeout: 15000,
  });
  if (started.error || started.status) {
    const psExe = path.join(process.env.SystemRoot || "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
    const fallback = spawnSync(fs.existsSync(psExe) ? psExe : "powershell.exe", [
      "-NoProfile",
      "-WindowStyle",
      "Hidden",
      "-Command",
      "Start-Process -FilePath $env:LTT_SWAP_CMD -WorkingDirectory $env:LTT_UPD_CWD -WindowStyle Hidden",
    ], {
      env,
      windowsHide: true,
      stdio: "ignore",
      timeout: 15000,
    });
    if (fallback.error) throw fallback.error;
    if (fallback.status) {
      throw started.error || new Error("无法启动更新脚本");
    }
  }
  setTimeout(() => app.exit(0), 500);
}

function applyPendingSwap() {
  if (!canSwapApp() || !nextDirReady()) return false;
  if (recentlyFailedSwap(swapPaths().lockFile)) return false;
  try {
    launchSwapAndQuit();
    return true;
  } catch {
    return false;
  }
}

function extraFeedUrls() {
  const out = [];
  const env = process.env.LTT_UPDATE_FEED;
  if (env) out.push(...env.split(/[,;\s]+/).filter(Boolean));
  const files = [];
  try {
    files.push(path.join(path.dirname(process.execPath), "update-feed.txt"));
  } catch {
    /* ignore */
  }
  if (app.isPackaged) files.push(path.join(process.resourcesPath, "update-feed.txt"));
  for (const f of files) {
    try {
      if (!fs.existsSync(f)) continue;
      for (const line of fs.readFileSync(f, "utf8").split(/\r?\n/)) {
        const s = line.trim();
        if (s && !s.startsWith("#") && /^https?:\/\//i.test(s)) out.push(s);
      }
    } catch {
      /* ignore */
    }
  }
  return out;
}

function fetchText(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    const req = net.request({ url, redirect: "follow" });
    const chunks = [];
    const timer = setTimeout(() => {
      try {
        req.abort();
      } catch {
        /* ignore */
      }
      reject(new Error("timeout"));
    }, timeoutMs);
    req.on("response", (res) => {
      if (res.statusCode >= 300) {
        clearTimeout(timer);
        reject(new Error("HTTP " + res.statusCode));
        return;
      }
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        clearTimeout(timer);
        resolve(Buffer.concat(chunks).toString("utf8"));
      });
      res.on("error", (e) => {
        clearTimeout(timer);
        reject(e);
      });
    });
    req.on("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
    req.end();
  });
}

function downloadFile(url, dest, onProgress) {
  return new Promise((resolve, reject) => {
    const req = net.request({ url, redirect: "follow" });
    const chunks = [];
    let received = 0;
    let total = 0;
    req.on("response", (res) => {
      if (res.statusCode >= 300) {
        reject(new Error("HTTP " + res.statusCode));
        return;
      }
      total = Number(res.headers["content-length"] || 0);
      res.on("data", (c) => {
        chunks.push(c);
        received += c.length;
        if (total > 0) onProgress(Math.min(0.99, received / total));
      });
      res.on("end", () => {
        fs.writeFileSync(dest, Buffer.concat(chunks));
        onProgress(1);
        resolve();
      });
      res.on("error", reject);
    });
    req.on("error", reject);
    req.end();
  });
}

async function fetchFeed() {
  const urls = [...extraFeedUrls(), ...FEED_URLS];
  let lastErr = new Error("无可用更新源");
  for (const url of urls) {
    try {
      const json = JSON.parse(await fetchText(url, 12000));
      if (!json || typeof json.version !== "string") throw new Error("feed");
      if (!json.sha256 || !Array.isArray(json.urls) || json.urls.length === 0) throw new Error("feed");
      return json;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr;
}

function extractZip(zipPath, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const tar = process.platform === "win32" ? "tar.exe" : "tar";
  return new Promise((resolve, reject) => {
    const p = spawn(tar, ["-xf", zipPath, "-C", dest], { windowsHide: true, stdio: "ignore" });
    p.on("error", reject);
    p.on("close", (code) => (code === 0 ? resolve() : reject(new Error("解压失败 " + code))));
  });
}

function walkFiles(dir, acc = []) {
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) walkFiles(p, acc);
    else acc.push(p);
  }
  return acc;
}

function assertNoZipSlip(root) {
  const resolved = path.resolve(root);
  for (const file of walkFiles(root)) {
    const rel = path.relative(resolved, file);
    if (rel.startsWith("..") || path.isAbsolute(rel)) throw new Error("更新包路径非法");
  }
}

function resolveAppRoot(dir) {
  const pkg = path.join(dir, "package.json");
  const html = path.join(dir, "dist", "index.html");
  const main = path.join(dir, "electron", "main.cjs");
  if (fs.existsSync(pkg) && fs.existsSync(html) && fs.existsSync(main)) return dir;
  const kids = fs.readdirSync(dir).filter((n) => !n.startsWith("."));
  if (kids.length === 1) {
    const inner = path.join(dir, kids[0]);
    if (fs.statSync(inner).isDirectory()) return resolveAppRoot(inner);
  }
  throw new Error("更新包内容不完整");
}

function removeWorkDir() {
  const work = path.join(process.resourcesPath, "ltt-update");
  try {
    if (fs.existsSync(work)) fs.rmSync(work, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
}

function cleanupLeftovers() {
  if (!app.isPackaged) return;
  const p = swapPaths();
  removeWorkDir();
  try {
    if (fs.existsSync(p.bakDir)) fs.rmSync(p.bakDir, { recursive: true, force: true });
  } catch {
    /* 可能仍被占用，下次再清 */
  }
  if (nextDirReady()) return;
  try {
    fs.rmSync(p.lockFile, { force: true });
  } catch {
    /* ignore */
  }
  try {
    if (fs.existsSync(p.nextDir)) fs.rmSync(p.nextDir, { recursive: true, force: true });
  } catch {
    /* ignore */
  }
}

async function checkUpdate(interactive) {
  const current = readLocalVersion();
  emit({
    phase: "checking",
    current,
    packaged: app.isPackaged,
    canApply: canSwapApp(),
    percent: 0,
    message: interactive ? "正在检查更新…" : undefined,
  });
  try {
    const feed = await fetchFeed();
    state.feed = feed;
    if (cmpVer(feed.version, current) <= 0) {
      return emit({
        phase: "upToDate",
        current,
        latest: feed.version,
        notes: feed.notes,
        size: feed.size,
        message: interactive ? "已是最新版本" : undefined,
        canApply: canSwapApp(),
      });
    }
    const needEl = String(feed.electron || "").replace(/^[^\d]*/, "");
    const haveEl = process.versions.electron || "0";
    const runtimeOk = !needEl || cmpVer(haveEl, needEl) >= 0;
    const apply = canSwapApp() && runtimeOk;
    return emit({
      phase: "available",
      current,
      latest: feed.version,
      notes: feed.notes || "",
      size: feed.size,
      publishedAt: feed.publishedAt,
      canApply: apply,
      message: apply
        ? undefined
        : runtimeOk
          ? "当前运行方式不支持增量替换，请下载完整绿色包"
          : "需要新的 Electron 运行库，请下载完整绿色包",
      fullUrl: feed.fullUrl,
    });
  } catch (e) {
    if (interactive) {
      return emit({
        phase: "error",
        current,
        message: "检查更新失败（网络或更新源不可用）",
      });
    }
    return emit({ phase: "idle", current, message: undefined });
  }
}

async function startUpdate() {
  const feed = state.feed;
  const current = readLocalVersion();
  if (!feed || cmpVer(feed.version, current) <= 0) {
    return checkUpdate(true);
  }
  if (!canSwapApp()) {
    return emit({
      phase: "available",
      message: "当前运行方式不支持自动替换，请下载完整绿色包覆盖",
      canApply: false,
    });
  }

  const p = swapPaths();
  const reuse = nextDirReady(feed.version);
  if (!reuse) {
    const work = path.join(process.resourcesPath, "ltt-update");
    const zipPath = path.join(work, "app.zip");
    const extractDir = path.join(work, "extract");

    try {
      fs.rmSync(work, { recursive: true, force: true });
      fs.rmSync(p.nextDir, { recursive: true, force: true });
      fs.mkdirSync(work, { recursive: true });
    } catch (e) {
      return emit({ phase: "error", message: "无法准备更新目录：" + String(e.message || e) });
    }

    emit({ phase: "downloading", percent: 0, message: "正在下载更新包…" });
    let downloaded = false;
    for (const url of feed.urls) {
      try {
        await downloadFile(url, zipPath, (prog) => emit({ phase: "downloading", percent: prog }));
        downloaded = true;
        break;
      } catch {
        /* try next url */
      }
    }
    if (!downloaded) {
      return emit({ phase: "error", message: "下载失败，请稍后重试或改用完整绿色包" });
    }

    emit({ phase: "verifying", percent: 1, message: "正在校验更新包…" });
    const hash = crypto.createHash("sha256").update(fs.readFileSync(zipPath)).digest("hex");
    if (hash.toLowerCase() !== String(feed.sha256).toLowerCase()) {
      return emit({ phase: "error", message: "更新包校验失败，已取消安装" });
    }

    try {
      fs.rmSync(extractDir, { recursive: true, force: true });
      await extractZip(zipPath, extractDir);
      assertNoZipSlip(extractDir);
      const root = resolveAppRoot(extractDir);
      const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
      if (String(pkg.version) !== String(feed.version)) throw new Error("版本不一致");
      fs.rmSync(p.nextDir, { recursive: true, force: true });
      fs.cpSync(root, p.nextDir, { recursive: true });
      removeWorkDir();
    } catch (e) {
      return emit({ phase: "error", message: "解压或校验失败：" + String(e.message || e) });
    }
  }

  emit({ phase: "applying", message: "即将重启以完成更新…" });
  try {
    launchSwapAndQuit();
  } catch (e) {
    return emit({ phase: "error", message: "无法启动更新脚本：" + String(e.message || e) });
  }
  return state;
}

function initUpdater() {
  state.current = readLocalVersion();
  state.packaged = app.isPackaged;
  if (applyPendingSwap()) return true;
  cleanupLeftovers();

  ipcMain.handle("ltt:getUpdate", () => state);
  ipcMain.handle("ltt:checkUpdate", () => checkUpdate(true));
  ipcMain.handle("ltt:startUpdate", () => startUpdate());
  ipcMain.handle("ltt:deferUpdate", () => emit({ ...state, deferred: true }));

  setTimeout(() => {
    void checkUpdate(false);
  }, 2500);
  setInterval(() => {
    if (state.phase === "downloading" || state.phase === "verifying" || state.phase === "applying") return;
    void checkUpdate(false);
  }, 6 * 60 * 60 * 1000);
  return false;
}

module.exports = { initUpdater };
