# Wait for the desktop process, swap resources/app, relaunch.
# Progress UI is a WinForms dialog only — never leave a PowerShell console behind.
param(
  [string]$PendingPath = "",
  [switch]$Ready
)

if (-not $Ready) {
  $ps = Join-Path $PSHOME "powershell.exe"
  $here = $PSCommandPath
  $arg = "-NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$here`" -Ready"
  if ($PendingPath) { $arg += " -PendingPath `"$PendingPath`"" }
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $ps
  $psi.Arguments = $arg
  $psi.UseShellExecute = $true
  $psi.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
  [void][System.Diagnostics.Process]::Start($psi)
  [Environment]::Exit(0)
}

$ErrorActionPreference = "Stop"
$log = Join-Path $env:TEMP "ltt-update-swap.log"
function Log($m) {
  try {
    Add-Content -LiteralPath $log -Value ("{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $m) -Encoding UTF8
  } catch {}
}

Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Runtime.InteropServices;

public static class LttNative {
  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct STARTUPINFO {
    public int cb;
    public IntPtr lpReserved;
    public IntPtr lpDesktop;
    public IntPtr lpTitle;
    public int dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
    public short wShowWindow, cbReserved2;
    public IntPtr lpReserved2, hStdInput, hStdOutput, hStdError;
  }
  [StructLayout(LayoutKind.Sequential)]
  public struct PROCESS_INFORMATION {
    public IntPtr hProcess, hThread;
    public int dwProcessId, dwThreadId;
  }
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  public static extern bool CreateProcess(string lpApplicationName, string lpCommandLine, IntPtr a, IntPtr t, bool inherit, uint flags, IntPtr env, string dir, ref STARTUPINFO si, out PROCESS_INFORMATION pi);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  [DllImport("kernel32.dll")] public static extern bool FreeConsole();
  [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

  public static void HideConsole() {
    IntPtr hwnd = GetConsoleWindow();
    if (hwnd != IntPtr.Zero) ShowWindow(hwnd, 0);
    FreeConsole();
  }

  public static bool LaunchDetached(string exe) {
    var si = new STARTUPINFO();
    si.cb = Marshal.SizeOf(typeof(STARTUPINFO));
    PROCESS_INFORMATION pi;
    uint flags = 0x01000000u | 0x00000200u | 0x00000008u;
    string dir = Path.GetDirectoryName(exe);
    string cmd = "\"" + exe + "\"";
    bool ok = CreateProcess(exe, cmd, IntPtr.Zero, IntPtr.Zero, false, flags, IntPtr.Zero, dir, ref si, out pi);
    if (ok) {
      CloseHandle(pi.hThread);
      CloseHandle(pi.hProcess);
    }
    return ok;
  }
}
"@
try { [LttNative]::HideConsole() } catch {}

$script:form = $null
$script:label = $null
function Pump {
  try {
    if ($script:form -and -not $script:form.IsDisposed) {
      [System.Windows.Forms.Application]::DoEvents()
    }
  } catch {}
}
function Set-Status($text) {
  Log $text
  try {
    if ($script:label -and -not $script:label.IsDisposed) {
      $script:label.Text = $text
      $script:form.Refresh()
    }
  } catch {}
  Pump
}
function Finish([int]$code) {
  try {
    if ($script:form -and -not $script:form.IsDisposed) {
      $script:form.Hide()
      $script:form.Dispose()
    }
  } catch {}
  try { [System.Windows.Forms.Application]::Exit() } catch {}
  [Environment]::Exit($code)
}

try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $script:form = New-Object System.Windows.Forms.Form
  $script:form.Text = "正在更新"
  $script:form.Size = New-Object System.Drawing.Size(460, 168)
  $script:form.StartPosition = "CenterScreen"
  $script:form.FormBorderStyle = "FixedDialog"
  $script:form.MaximizeBox = $false
  $script:form.MinimizeBox = $false
  $script:form.TopMost = $true
  $script:label = New-Object System.Windows.Forms.Label
  $script:label.Location = New-Object System.Drawing.Point(16, 16)
  $script:label.Size = New-Object System.Drawing.Size(412, 52)
  $script:label.Text = "正在更新，请不要关闭此窗口。`r`n通常十几秒内完成，完成后会自动启动。"
  $bar = New-Object System.Windows.Forms.ProgressBar
  $bar.Location = New-Object System.Drawing.Point(16, 80)
  $bar.Size = New-Object System.Drawing.Size(412, 22)
  $bar.Style = "Marquee"
  $bar.MarqueeAnimationSpeed = 30
  $script:form.Controls.Add($script:label)
  $script:form.Controls.Add($bar)
  $script:form.Show()
  $script:form.Refresh()
  Pump
} catch {
  Log "form fail $($_.Exception.Message)"
}

function Read-Pending {
  $candidates = @()
  if ($PendingPath) { $candidates += $PendingPath }
  if ($env:LTT_UPD_PENDING) { $candidates += $env:LTT_UPD_PENDING }
  if ($PSScriptRoot) { $candidates += (Join-Path $PSScriptRoot "ltt-update-pending.json") }
  if ($env:LTT_UPD_CWD) { $candidates += (Join-Path $env:LTT_UPD_CWD "ltt-update-pending.json") }
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    if (-not (Test-Path -LiteralPath $c)) { continue }
    try {
      return (Get-Content -LiteralPath $c -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
      Log "pending parse fail $c $($_.Exception.Message)"
    }
  }
  return $null
}

Log "begin"
$p = Read-Pending
$pidToWait = 0
if ($p -and $p.pid) { [void][int]::TryParse([string]$p.pid, [ref]$pidToWait) }
if ($pidToWait -le 0) { [void][int]::TryParse($env:LTT_UPD_PID, [ref]$pidToWait) }
$exe = if ($p -and $p.exe) { [string]$p.exe } else { $env:LTT_UPD_EXE }
$app = if ($p -and $p.app) { [string]$p.app } else { $env:LTT_UPD_APP }
$next = if ($p -and $p.next) { [string]$p.next } else { $env:LTT_UPD_NEXT }
$bak = if ($p -and $p.bak) { [string]$p.bak } else { $env:LTT_UPD_BAK }

Log "pid=$pidToWait exe=$exe"
Log "app=$app"
Log "next=$next"

if (-not $exe -or -not $app -or -not $next -or -not $bak) {
  Set-Status "更新失败：缺少路径参数"
  Start-Sleep -Seconds 3
  Finish 1
}

function Get-AppProcs {
  Get-Process -ErrorAction SilentlyContinue | Where-Object {
    if ($_.Id -eq $PID) { return $false }
    try {
      $path = $_.Path
      return $path -and ($path -ieq $exe)
    } catch {
      return $false
    }
  }
}

# The bridge is outside resources/app in the normal green-package layout, so
# killing only the Electron process is not enough to release the installation.
$resourcesDir = Split-Path -Parent $app
$installDir = Split-Path -Parent $resourcesDir
$bridgeExePaths = @(
  (Join-Path $app "bridge\python\python.exe"),
  (Join-Path $resourcesDir "bridge\python\python.exe"),
  (Join-Path $installDir "bridge\python\python.exe"),
  (Join-Path $app "tools\.venv\Scripts\python.exe"),
  (Join-Path $resourcesDir "tools\.venv\Scripts\python.exe"),
  (Join-Path $installDir "tools\.venv\Scripts\python.exe")
)
$bridgeScriptPaths = @(
  (Join-Path $app "bridge\tdx_flow_server.py"),
  (Join-Path $resourcesDir "bridge\tdx_flow_server.py"),
  (Join-Path $installDir "bridge\tdx_flow_server.py"),
  (Join-Path $app "tools\tdx_flow_server.py"),
  (Join-Path $resourcesDir "tools\tdx_flow_server.py"),
  (Join-Path $installDir "tools\tdx_flow_server.py")
)

function Get-BridgeProcs {
  $rows = @()
  try { $rows = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) } catch { $rows = @() }
  $matches = @()
  foreach ($row in $rows) {
    if (-not $row.ProcessId -or $row.ProcessId -eq $PID) { continue }
    $hit = $false
    $exePath = [string]$row.ExecutablePath
    foreach ($candidate in $bridgeExePaths) {
      if ($exePath -and ($exePath -ieq [string]$candidate)) {
        $hit = $true
        break
      }
    }
    if (-not $hit) {
      $commandLine = [string]$row.CommandLine
      foreach ($scriptPath in $bridgeScriptPaths) {
        if ($commandLine -and $scriptPath -and $commandLine.IndexOf([string]$scriptPath, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
          $hit = $true
          break
        }
      }
    }
    if ($hit) { $matches += $row }
  }
  if ($matches.Count -eq 0) {
    # WMI 可能被安全软件或系统负载拖慢；8899 是本软件桥接专用端口，
    # 进程枚举失败时仍按监听 PID 回收，避免更新后留下 DLL 文件锁。
    try {
      $listeners = @(Get-NetTCPConnection -LocalPort 8899 -State Listen -ErrorAction SilentlyContinue)
      foreach ($listener in $listeners) {
        if ($listener.OwningProcess -and $listener.OwningProcess -ne $PID) {
          $matches += [pscustomobject]@{ ProcessId = [int]$listener.OwningProcess }
        }
      }
    } catch {}
  }
  return $matches
}

function Stop-Bridge {
  $bridges = @(Get-BridgeProcs)
  if ($bridges.Count -eq 0) { return }
  Set-Status "正在结束资金流桥接…"
  foreach ($bridge in $bridges) {
    try { Stop-Process -Id ([int]$bridge.ProcessId) -Force -ErrorAction SilentlyContinue } catch {}
  }
  $deadline = (Get-Date).AddMilliseconds(2500)
  while ((Get-Date) -lt $deadline) {
    Pump
    if (@(Get-BridgeProcs).Count -eq 0) { break }
    Start-Sleep -Milliseconds 50
  }
}

function Wait-AppGone([int]$ms) {
  $deadline = (Get-Date).AddMilliseconds($ms)
  while ((Get-Date) -lt $deadline) {
    Pump
    $main = $null
    if ($pidToWait -gt 0) {
      $main = Get-Process -Id $pidToWait -ErrorAction SilentlyContinue
    }
    $kids = @(Get-AppProcs)
    if (-not $main -and $kids.Count -eq 0) { return }
    Start-Sleep -Milliseconds 40
  }
}

$mainAlive = $false
if ($pidToWait -gt 0) {
  $mainAlive = [bool](Get-Process -Id $pidToWait -ErrorAction SilentlyContinue)
}
$kidsAlive = @(Get-AppProcs)
Stop-Bridge
if ($mainAlive -or $kidsAlive.Count -gt 0) {
  Set-Status "正在结束旧进程…"
  if ($pidToWait -gt 0) {
    try { Stop-Process -Id $pidToWait -Force -ErrorAction SilentlyContinue } catch {}
  }
  $kidsAlive | ForEach-Object {
    try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
  }
  Wait-AppGone 2000
}
Start-Sleep -Milliseconds 120
Pump

function Start-App {
  Log "start $exe"
  if (-not (Test-Path -LiteralPath $exe)) {
    Log "exe missing"
    return
  }
  $ok = $false
  try { $ok = [LttNative]::LaunchDetached($exe) } catch { Log "native launch fail $($_.Exception.Message)" }
  if ($ok) { Log "started detached"; return }
  Log "fallback shellexecute"
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $exe
  $psi.WorkingDirectory = Split-Path -Parent $exe
  $psi.UseShellExecute = $true
  [void][System.Diagnostics.Process]::Start($psi)
}

function Restore-App {
  if ((Test-Path -LiteralPath $bak) -and -not (Test-Path -LiteralPath $app)) {
    try {
      Rename-Item -LiteralPath $bak -NewName (Split-Path -Leaf $app) -ErrorAction Stop
      Log "restored bak"
    } catch {
      Log "restore fail $($_.Exception.Message)"
    }
  }
}

$appName = Split-Path -Leaf $app
$bakName = Split-Path -Leaf $bak
Set-Status "正在替换程序文件…"

$ok = $false
for ($i = 0; $i -lt 40; $i++) {
  Pump
  try {
    if (Test-Path -LiteralPath $bak) {
      Remove-Item -LiteralPath $bak -Recurse -Force -ErrorAction Stop
    }
    if (-not (Test-Path -LiteralPath $app)) { throw "missing app" }
    if (-not (Test-Path -LiteralPath $next)) { throw "missing next" }
    Rename-Item -LiteralPath $app -NewName $bakName -ErrorAction Stop
    Log "renamed app -> $bakName"
    try {
      Rename-Item -LiteralPath $next -NewName $appName -ErrorAction Stop
    } catch {
      Log "rename next fail $($_.Exception.Message)"
      Restore-App
      throw
    }
    Log "renamed next -> $appName"
    $ok = $true
    break
  } catch {
    Log "retry $i $($_.Exception.Message)"
    Stop-Bridge
    Get-AppProcs | ForEach-Object {
      try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
    }
    Start-Sleep -Milliseconds 200
  }
}

if ($ok) {
  Set-Status "替换完成，即将启动新版本…"
  Pump
  Start-App
  Log "ok"
  Finish 0
}

Set-Status "未能替换文件，正在启动原版本…"
Log "giveup"
Restore-App
Start-App
Start-Sleep -Seconds 2
Finish 1
