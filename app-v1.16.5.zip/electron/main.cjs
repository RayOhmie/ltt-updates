// 龙抬头·专业盯盘分析终端 —— Windows 桌面版入口
const { app, BrowserWindow, shell, session } = require("electron");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const { initUpdater } = require("./updater.cjs");

// 竞价站/行情接口：桌面版为主进程直连（其接口无 CORS 头，浏览器网页版受跨域限制）
app.commandLine.appendSwitch("disable-features", "OutOfBlinkCors");

/** 通达信分笔资金流桥接：存在可用的 python 环境时静默拉起，失败不影响主程序 */
function startFlowBridge() {
  const appDir = __dirname; // 开发=<项目>/electron；打包=<释放目录>/resources/app
  const candidates = [
    // 显式指定
    process.env.TDX_FLOW_PYEXE && process.env.TDX_FLOW_SCRIPT
      ? { py: process.env.TDX_FLOW_PYEXE, script: process.env.TDX_FLOW_SCRIPT }
      : null,
    // 便携桥接包（开发态：<项目>/bridge）
    {
      py: path.join(appDir, "..", "bridge", "python", "python.exe"),
      script: path.join(appDir, "..", "bridge", "tdx_flow_server.py"),
    },
    // 便携桥接包（绿色版：<释放目录>/bridge）
    {
      py: path.join(appDir, "..", "..", "bridge", "python", "python.exe"),
      script: path.join(appDir, "..", "..", "bridge", "tdx_flow_server.py"),
    },
    // 开发态：<项目>/tools/.venv
    {
      py: path.join(appDir, "..", "tools", ".venv", "Scripts", "python.exe"),
      script: path.join(appDir, "..", "tools", "tdx_flow_server.py"),
    },
    // 绿色版：<释放目录>/tools/.venv
    {
      py: path.join(appDir, "..", "..", "tools", ".venv", "Scripts", "python.exe"),
      script: path.join(appDir, "..", "..", "tools", "tdx_flow_server.py"),
    },
    // 自用兜底：本机项目目录的 venv（仅供本机使用，其他机器靠上面两个候选或环境变量）
    {
      py: "D:\\AI Coding\\Project\\CodexProject\\AShareMaster\\tools\\.venv\\Scripts\\python.exe",
      script: "D:\\AI Coding\\Project\\CodexProject\\AShareMaster\\tools\\tdx_flow_server.py",
    },
  ].filter(Boolean);
  for (const c of candidates) {
    if (!fs.existsSync(c.py) || !fs.existsSync(c.script)) continue;
    try {
      const child = spawn(c.py, [c.script], { stdio: "ignore", windowsHide: true });
      child.on("error", () => {});
      child.unref();
    } catch {
      /* 桥接启动失败不影响主程序 */
    }
    return;
  }
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1680,
    height: 1000,
    minWidth: 1366,
    minHeight: 800,
    show: false,
    backgroundColor: "#0b0e14",
    autoHideMenuBar: true,
    title: "龙抬头·专业盯盘分析终端",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false, // 本地桌面软件直连行情/竞价接口（file:// 页面访问 https 数据接口需要）
    },
  });
  win.once("ready-to-show", () => {
    win.maximize();
    win.show();
  });
  // 外链一律交给系统浏览器
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
  win.loadFile(path.join(__dirname, "../dist/index.html"));
}

app.whenReady().then(() => {
  if (initUpdater()) return;
  startFlowBridge();
  // 兜底：对数据接口请求不发送/不校验 Origin，避免个别网关按 Origin 拒绝
  session.defaultSession.webRequest.onBeforeSendHeaders((details, callback) => {
    const h = details.requestHeaders;
    if (/gtimg\.cn|eastmoney\.com|qq\.com/.test(details.url)) delete h["Origin"];
    callback({ requestHeaders: h });
  });
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  app.quit();
});
