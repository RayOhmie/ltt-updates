# Silent helper: wait for the desktop PID, rename resources/app, relaunch.
# Invoked hidden (CREATE_NO_WINDOW / -WindowStyle Hidden). No console host.
param([string]$PendingPath = "")
$ErrorActionPreference = "Stop"
$log = Join-Path $env:TEMP "ltt-update-swap.log"
function Log($m) {
  try {
    Add-Content -LiteralPath $log -Value ("{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $m) -Encoding UTF8
  } catch {}
}

function Read-Pending {
  $candidates = @()
  if ($PendingPath) { $candidates += $PendingPath }
  if ($env:LTT_UPD_PENDING) { $candidates += $env:LTT_UPD_PENDING }
  if ($PSScriptRoot) { $candidates += (Join-Path $PSScriptRoot "ltt-update-pending.json") }
  if ($env:LTT_UPD_CWD) { $candidates += (Join-Path $env:LTT_UPD_CWD "ltt-update-pending.json") }
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    if (-not (Test-Path -LiteralPath $c)) { continue }
    try {
      return (Get-Content -LiteralPath $c -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
      Log "pending parse fail $c $($_.Exception.Message)"
    }
  }
  return $null
}

Log "begin"
$p = Read-Pending
$pidToWait = 0
if ($p -and $p.pid) { [void][int]::TryParse([string]$p.pid, [ref]$pidToWait) }
if ($pidToWait -le 0) { [void][int]::TryParse($env:LTT_UPD_PID, [ref]$pidToWait) }
$exe = if ($p -and $p.exe) { [string]$p.exe } else { $env:LTT_UPD_EXE }
$app = if ($p -and $p.app) { [string]$p.app } else { $env:LTT_UPD_APP }
$next = if ($p -and $p.next) { [string]$p.next } else { $env:LTT_UPD_NEXT }
$bak = if ($p -and $p.bak) { [string]$p.bak } else { $env:LTT_UPD_BAK }

Log "pid=$pidToWait exe=$exe"
Log "app=$app"
Log "next=$next"

if (-not $exe -or -not $app -or -not $next -or -not $bak) {
  Log "missing paths"
  exit 1
}

if ($pidToWait -gt 0) {
  try {
    Log "wait pid $pidToWait"
    Wait-Process -Id $pidToWait -Timeout 90 -ErrorAction SilentlyContinue
  } catch {}
  Log "pid wait done"
}
Start-Sleep -Milliseconds 1500

function Start-App {
  Log "start $exe"
  if (Test-Path -LiteralPath $exe) {
    Start-Process -FilePath $exe | Out-Null
  } else {
    Log "exe missing"
  }
}

function Restore-App {
  if ((Test-Path -LiteralPath $bak) -and -not (Test-Path -LiteralPath $app)) {
    try {
      Rename-Item -LiteralPath $bak -NewName (Split-Path -Leaf $app) -ErrorAction Stop
      Log "restored bak"
    } catch {
      Log "restore fail $($_.Exception.Message)"
    }
  }
}

$appName = Split-Path -Leaf $app
$bakName = Split-Path -Leaf $bak

for ($i = 0; $i -lt 90; $i++) {
  try {
    if (Test-Path -LiteralPath $bak) {
      Remove-Item -LiteralPath $bak -Recurse -Force -ErrorAction Stop
    }
    if (-not (Test-Path -LiteralPath $app)) { throw "missing app" }
    if (-not (Test-Path -LiteralPath $next)) { throw "missing next" }
    Rename-Item -LiteralPath $app -NewName $bakName -ErrorAction Stop
    Log "renamed app -> $bakName"
    try {
      Rename-Item -LiteralPath $next -NewName $appName -ErrorAction Stop
    } catch {
      Log "rename next fail $($_.Exception.Message)"
      Restore-App
      throw
    }
    Log "renamed next -> $appName"
    Start-App
    Log "ok"
    exit 0
  } catch {
    Log "retry $i $($_.Exception.Message)"
    Start-Sleep -Milliseconds 500
  }
}

Log "giveup"
Restore-App
Start-App
exit 1
