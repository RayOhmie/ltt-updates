# Wait for the desktop process, swap resources/app, relaunch.
# First instance (old hidden launchers) respawns a visible STA window, then exits.
param(
  [string]$PendingPath = "",
  [switch]$Ready
)

if (-not $Ready) {
  $ps = Join-Path $PSHOME "powershell.exe"
  $here = $PSCommandPath
  $arg = "-NoProfile -STA -ExecutionPolicy Bypass -File `"$here`" -Ready"
  if ($PendingPath) { $arg += " -PendingPath `"$PendingPath`"" }
  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = $ps
  $psi.Arguments = $arg
  $psi.UseShellExecute = $true
  [void][System.Diagnostics.Process]::Start($psi)
  exit 0
}

$ErrorActionPreference = "Stop"
$log = Join-Path $env:TEMP "ltt-update-swap.log"
function Log($m) {
  try {
    Add-Content -LiteralPath $log -Value ("{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"), $m) -Encoding UTF8
  } catch {}
}

$script:form = $null
$script:label = $null
function Pump {
  try {
    if ($script:form -and -not $script:form.IsDisposed) {
      [System.Windows.Forms.Application]::DoEvents()
    }
  } catch {}
}
function Set-Status($text) {
  Log $text
  try {
    if ($script:label -and -not $script:label.IsDisposed) {
      $script:label.Text = $text
      $script:form.Refresh()
    } else {
      Write-Host $text
    }
  } catch {
    Write-Host $text
  }
  Pump
}

try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $script:form = New-Object System.Windows.Forms.Form
  $script:form.Text = "正在更新"
  $script:form.Size = New-Object System.Drawing.Size(460, 168)
  $script:form.StartPosition = "CenterScreen"
  $script:form.FormBorderStyle = "FixedDialog"
  $script:form.MaximizeBox = $false
  $script:form.MinimizeBox = $false
  $script:form.TopMost = $true
  $script:label = New-Object System.Windows.Forms.Label
  $script:label.Location = New-Object System.Drawing.Point(16, 16)
  $script:label.Size = New-Object System.Drawing.Size(412, 52)
  $script:label.Text = "正在更新，请不要关闭此窗口。`r`n通常约 1 分钟内完成，完成后会自动启动。"
  $bar = New-Object System.Windows.Forms.ProgressBar
  $bar.Location = New-Object System.Drawing.Point(16, 80)
  $bar.Size = New-Object System.Drawing.Size(412, 22)
  $bar.Style = "Marquee"
  $bar.MarqueeAnimationSpeed = 30
  $script:form.Controls.Add($script:label)
  $script:form.Controls.Add($bar)
  $script:form.Show()
  $script:form.Refresh()
  Pump
  try {
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class LttWin32 {
  [DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@
    $hwnd = [LttWin32]::GetConsoleWindow()
    if ($hwnd -ne [IntPtr]::Zero) { [void][LttWin32]::ShowWindow($hwnd, 0) }
  } catch {}
} catch {
  $Host.UI.RawUI.WindowTitle = "正在更新"
  Write-Host ""
  Write-Host "  正在更新，请不要关闭本窗口。"
  Write-Host "  通常约 1 分钟内完成，完成后会自动启动。"
  Write-Host ""
}

function Read-Pending {
  $candidates = @()
  if ($PendingPath) { $candidates += $PendingPath }
  if ($env:LTT_UPD_PENDING) { $candidates += $env:LTT_UPD_PENDING }
  if ($PSScriptRoot) { $candidates += (Join-Path $PSScriptRoot "ltt-update-pending.json") }
  if ($env:LTT_UPD_CWD) { $candidates += (Join-Path $env:LTT_UPD_CWD "ltt-update-pending.json") }
  foreach ($c in $candidates) {
    if (-not $c) { continue }
    if (-not (Test-Path -LiteralPath $c)) { continue }
    try {
      return (Get-Content -LiteralPath $c -Raw -Encoding UTF8 | ConvertFrom-Json)
    } catch {
      Log "pending parse fail $c $($_.Exception.Message)"
    }
  }
  return $null
}

Log "begin"
$p = Read-Pending
$pidToWait = 0
if ($p -and $p.pid) { [void][int]::TryParse([string]$p.pid, [ref]$pidToWait) }
if ($pidToWait -le 0) { [void][int]::TryParse($env:LTT_UPD_PID, [ref]$pidToWait) }
$exe = if ($p -and $p.exe) { [string]$p.exe } else { $env:LTT_UPD_EXE }
$app = if ($p -and $p.app) { [string]$p.app } else { $env:LTT_UPD_APP }
$next = if ($p -and $p.next) { [string]$p.next } else { $env:LTT_UPD_NEXT }
$bak = if ($p -and $p.bak) { [string]$p.bak } else { $env:LTT_UPD_BAK }

Log "pid=$pidToWait exe=$exe"
Log "app=$app"
Log "next=$next"

if (-not $exe -or -not $app -or -not $next -or -not $bak) {
  Set-Status "更新失败：缺少路径参数"
  Start-Sleep -Seconds 4
  exit 1
}

function Get-AppProcs {
  Get-Process -ErrorAction SilentlyContinue | Where-Object {
    if ($_.Id -eq $PID) { return $false }
    try {
      $path = $_.Path
      return $path -and ($path -ieq $exe)
    } catch {
      return $false
    }
  }
}

Set-Status "正在等待程序退出…"
if ($pidToWait -gt 0) {
  try { Wait-Process -Id $pidToWait -Timeout 15 -ErrorAction SilentlyContinue } catch {}
  try { Stop-Process -Id $pidToWait -Force -ErrorAction SilentlyContinue } catch {}
}
Get-AppProcs | ForEach-Object {
  try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
}
Start-Sleep -Milliseconds 400
Pump

function Start-App {
  Log "start $exe"
  if (Test-Path -LiteralPath $exe) {
    Start-Process -FilePath $exe | Out-Null
  } else {
    Log "exe missing"
  }
}

function Restore-App {
  if ((Test-Path -LiteralPath $bak) -and -not (Test-Path -LiteralPath $app)) {
    try {
      Rename-Item -LiteralPath $bak -NewName (Split-Path -Leaf $app) -ErrorAction Stop
      Log "restored bak"
    } catch {
      Log "restore fail $($_.Exception.Message)"
    }
  }
}

$appName = Split-Path -Leaf $app
$bakName = Split-Path -Leaf $bak
Set-Status "正在替换程序文件…"

$ok = $false
for ($i = 0; $i -lt 40; $i++) {
  Pump
  try {
    if (Test-Path -LiteralPath $bak) {
      Remove-Item -LiteralPath $bak -Recurse -Force -ErrorAction Stop
    }
    if (-not (Test-Path -LiteralPath $app)) { throw "missing app" }
    if (-not (Test-Path -LiteralPath $next)) { throw "missing next" }
    Rename-Item -LiteralPath $app -NewName $bakName -ErrorAction Stop
    Log "renamed app -> $bakName"
    try {
      Rename-Item -LiteralPath $next -NewName $appName -ErrorAction Stop
    } catch {
      Log "rename next fail $($_.Exception.Message)"
      Restore-App
      throw
    }
    Log "renamed next -> $appName"
    $ok = $true
    break
  } catch {
    Log "retry $i $($_.Exception.Message)"
    Get-AppProcs | ForEach-Object {
      try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
    }
    Start-Sleep -Milliseconds 200
  }
}

if ($ok) {
  Set-Status "替换完成，即将启动新版本…"
  Start-Sleep -Milliseconds 400
  Start-App
  Log "ok"
  if ($script:form -and -not $script:form.IsDisposed) { $script:form.Close() }
  exit 0
}

Set-Status "未能替换文件，正在启动原版本…"
Log "giveup"
Restore-App
Start-App
Start-Sleep -Seconds 3
if ($script:form -and -not $script:form.IsDisposed) { $script:form.Close() }
exit 1
