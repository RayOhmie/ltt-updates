@echo off
setlocal EnableExtensions
REM Compatibility trampoline for old clients that still "start" this .cmd.
REM Do not start another .cmd (paths with spaces -> "找不到批处理文件").
REM Fire a hidden PowerShell worker and exit immediately so the console can close.
if not defined LTT_UPD_CWD set "LTT_UPD_CWD=%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
"%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "Start-Process -FilePath (Join-Path $PSHOME 'powershell.exe') -WorkingDirectory $env:LTT_UPD_CWD -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',(Join-Path $env:LTT_UPD_CWD 'ltt-update-swap.ps1')"
exit /b 0
