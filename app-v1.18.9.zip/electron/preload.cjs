// 渲染进程桥：自动更新 IPC（contextIsolation）
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("lttDesktop", {
  onUpdate: (cb) => {
    const fn = (_e, payload) => cb(payload);
    ipcRenderer.on("ltt:update", fn);
    return () => ipcRenderer.removeListener("ltt:update", fn);
  },
  getUpdate: () => ipcRenderer.invoke("ltt:getUpdate"),
  checkUpdate: () => ipcRenderer.invoke("ltt:checkUpdate"),
  startUpdate: () => ipcRenderer.invoke("ltt:startUpdate"),
  deferUpdate: () => ipcRenderer.invoke("ltt:deferUpdate"),
});
