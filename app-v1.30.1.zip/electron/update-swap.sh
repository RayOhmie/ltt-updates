#!/bin/bash
# Wait for the desktop process, swap Contents/Resources/app, relaunch.
# Mirrors update-swap.ps1 so Windows / macOS share the same app.zip.

set +e
LOG="${TMPDIR:-/tmp}/ltt-update-swap.log"
PENDING_PATH="${1:-}"

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >>"$LOG" 2>/dev/null
}

notify() {
  local msg="$1"
  log "$msg"
  /usr/bin/osascript -e "display notification \"$msg\" with title \"软件更新\"" >/dev/null 2>&1 || true
}

read_json_field() {
  local file="$1"
  local key="$2"
  /usr/bin/python3 - "$file" "$key" <<'PY' 2>/dev/null
import json, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    val = data.get(sys.argv[2], "")
    print("" if val is None else val)
except Exception:
    pass
PY
}

read_pkg_ver() {
  local dir="$1"
  if [ -z "$dir" ] || [ ! -f "$dir/package.json" ]; then
    echo ""
    return
  fi
  /usr/bin/python3 - "$dir/package.json" <<'PY' 2>/dev/null
import json, sys
try:
    print(json.load(open(sys.argv[1], encoding="utf-8")).get("version", ""))
except Exception:
    print("")
PY
}

bundle_from_exe() {
  local exe="$1"
  case "$exe" in
    *.app/Contents/MacOS/*)
      echo "${exe%%.app/Contents/MacOS/*}.app"
      ;;
    *)
      echo ""
      ;;
  esac
}

alive() {
  local pid="$1"
  [ -n "$pid" ] && [ "$pid" -gt 0 ] 2>/dev/null && kill -0 "$pid" 2>/dev/null
}

kill_pid() {
  local pid="$1"
  if alive "$pid"; then
    kill "$pid" 2>/dev/null
    sleep 0.15
    if alive "$pid"; then
      kill -9 "$pid" 2>/dev/null
    fi
  fi
}

pids_listening() {
  /usr/sbin/lsof -nP -iTCP:8899 -sTCP:LISTEN -t 2>/dev/null | awk 'NF && $1+0 == $1 {print $1}'
}

pids_matching_exe() {
  local exe="$1"
  [ -z "$exe" ] && return
  /bin/ps -ax -o pid=,command= 2>/dev/null | while IFS= read -r line; do
    pid="${line%% *}"
    cmd="${line#* }"
    cmd="${cmd#"${cmd%%[![:space:]]*}"}"
    case "$cmd" in
      "$exe"|"$exe "*) echo "$pid" ;;
    esac
  done
}

stop_bridge() {
  local install_dir="$1"
  local pids
  pids="$(pids_listening)"
  if [ -n "$install_dir" ]; then
    extra="$(/bin/ps -ax -o pid=,command= 2>/dev/null | awk -v root="$install_dir" '
      index($0, root) && ($0 ~ /tdx_flow_server\.py/ || $0 ~ /bridge\/python/) { print $1 }
    ')"
    pids="$(printf '%s\n%s\n' "$pids" "$extra" | awk 'NF && !seen[$0]++')"
  fi
  if [ -z "$pids" ]; then
    return
  fi
  log "stop bridge $pids"
  for pid in $pids; do
    kill_pid "$pid"
  done
}

log "begin"
CANDIDATES=""
if [ -n "$PENDING_PATH" ]; then CANDIDATES="$CANDIDATES
$PENDING_PATH"; fi
if [ -n "${LTT_UPD_PENDING:-}" ]; then CANDIDATES="$CANDIDATES
$LTT_UPD_PENDING"; fi
if [ -n "${LTT_UPD_CWD:-}" ]; then CANDIDATES="$CANDIDATES
$LTT_UPD_CWD/ltt-update-pending.json"; fi

PENDING=""
for c in $CANDIDATES; do
  [ -z "$c" ] && continue
  if [ -f "$c" ]; then
    PENDING="$c"
    break
  fi
done

PID_TO_WAIT="${LTT_UPD_PID:-0}"
EXE="${LTT_UPD_EXE:-}"
APP="${LTT_UPD_APP:-}"
NEXT="${LTT_UPD_NEXT:-}"
BAK="${LTT_UPD_BAK:-}"
CUR_VER="${LTT_UPD_CURRENT:-}"
LAT_VER="${LTT_UPD_LATEST:-}"

if [ -n "$PENDING" ]; then
  [ "$PID_TO_WAIT" = "0" ] && PID_TO_WAIT="$(read_json_field "$PENDING" pid)"
  [ -z "$EXE" ] && EXE="$(read_json_field "$PENDING" exe)"
  [ -z "$APP" ] && APP="$(read_json_field "$PENDING" app)"
  [ -z "$NEXT" ] && NEXT="$(read_json_field "$PENDING" next)"
  [ -z "$BAK" ] && BAK="$(read_json_field "$PENDING" bak)"
  [ -z "$CUR_VER" ] && CUR_VER="$(read_json_field "$PENDING" current)"
  [ -z "$LAT_VER" ] && LAT_VER="$(read_json_field "$PENDING" latest)"
fi

[ -z "$CUR_VER" ] && CUR_VER="$(read_pkg_ver "$APP")"
[ -z "$LAT_VER" ] && LAT_VER="$(read_pkg_ver "$NEXT")"
BUNDLE="$(bundle_from_exe "$EXE")"
RESOURCES_DIR="$(dirname "$APP")"
INSTALL_DIR="$(dirname "$(dirname "$RESOURCES_DIR")")"
# .app/Contents/Resources -> install dir is parent of .app
case "$RESOURCES_DIR" in
  */Contents/Resources) INSTALL_DIR="$(dirname "$(dirname "$RESOURCES_DIR")")" ;;
esac

log "pid=$PID_TO_WAIT exe=$EXE current=$CUR_VER latest=$LAT_VER"
log "app=$APP next=$NEXT bak=$BAK bundle=$BUNDLE"

if [ -z "$EXE" ] || [ -z "$APP" ] || [ -z "$NEXT" ] || [ -z "$BAK" ]; then
  notify "更新失败：缺少路径参数"
  exit 1
fi

notify "正在更新 ${CUR_VER:+v$CUR_VER }→ ${LAT_VER:+v$LAT_VER}…"
stop_bridge "$INSTALL_DIR"

if alive "$PID_TO_WAIT"; then
  log "wait/stop main $PID_TO_WAIT"
  kill_pid "$PID_TO_WAIT"
fi
for pid in $(pids_matching_exe "$EXE"); do
  [ "$pid" = "$$" ] && continue
  kill_pid "$pid"
done

for _ in $(seq 1 50); do
  if ! alive "$PID_TO_WAIT"; then
    leftover="$(pids_matching_exe "$EXE")"
    [ -z "$leftover" ] && break
  fi
  sleep 0.04
done
sleep 0.12

APP_NAME="$(basename "$APP")"
BAK_NAME="$(basename "$BAK")"
PARENT="$(dirname "$APP")"
ok=0
for i in $(seq 0 39); do
  rm -rf "$BAK"
  if [ ! -d "$APP" ] || [ ! -d "$NEXT" ]; then
    log "retry $i missing app/next"
    stop_bridge "$INSTALL_DIR"
    sleep 0.2
    continue
  fi
  if mv "$APP" "$BAK"; then
    log "renamed app -> $BAK_NAME"
    if mv "$NEXT" "$PARENT/$APP_NAME"; then
      log "renamed next -> $APP_NAME"
      ok=1
      break
    fi
    log "rename next fail, restore"
    if [ -d "$BAK" ] && [ ! -d "$APP" ]; then
      mv "$BAK" "$APP"
    fi
  fi
  log "retry $i"
  stop_bridge "$INSTALL_DIR"
  for pid in $(pids_matching_exe "$EXE"); do
    kill_pid "$pid"
  done
  sleep 0.2
done

start_app() {
  if [ -n "$BUNDLE" ] && [ -d "$BUNDLE" ]; then
    log "open $BUNDLE"
    /usr/bin/open -n "$BUNDLE"
    return
  fi
  if [ -x "$EXE" ]; then
    log "exec $EXE"
    (cd "$(dirname "$EXE")" && "$EXE") >/dev/null 2>&1 &
  fi
}

if [ "$ok" = "1" ]; then
  notify "替换完成，正在启动新版本"
  start_app
  log "ok"
  exit 0
fi

notify "未能替换文件，正在启动原版本"
if [ -d "$BAK" ] && [ ! -d "$APP" ]; then
  mv "$BAK" "$APP"
  log "restored bak"
fi
start_app
exit 1
