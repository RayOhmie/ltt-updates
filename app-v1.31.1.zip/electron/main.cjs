// 龙抬头·专业盯盘分析终端 —— 桌面入口（Windows / macOS 同一套主进程）
const { app, BrowserWindow, Menu, shell, session } = require("electron");
const path = require("path");
const fs = require("fs");
const os = require("os");
const net = require("net");
const { spawn, execFile } = require("child_process");
const { initUpdater } = require("./updater.cjs");

const isWin = process.platform === "win32";
const isMac = process.platform === "darwin";

// 竞价站/行情接口：桌面版为主进程直连（其接口无 CORS 头，浏览器网页版受跨域限制）
app.commandLine.appendSwitch("disable-features", "OutOfBlinkCors");

let flowBridge = null;
let bridgeStartPromise = null;
let bridgeStopPromise = null;
let shutdownStarted = false;
let shutdownDone = false;
const trackedBridgePids = new Set();

function isLocalPortOpen(port) {
  return new Promise((resolve) => {
    const sock = net.connect({ host: "127.0.0.1", port, timeout: 400 });
    const done = (v) => {
      try {
        sock.destroy();
      } catch {
        /* ignore */
      }
      resolve(v);
    };
    sock.once("connect", () => done(true));
    sock.once("error", () => done(false));
    sock.once("timeout", () => done(false));
  });
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function joinFromApp(...rel) {
  return path.join(__dirname, ...rel);
}

/** Windows 绿色版路径保持原样；macOS 用 unix venv / 便携 python。 */
function bridgeCandidates() {
  const env =
    process.env.TDX_FLOW_PYEXE && process.env.TDX_FLOW_SCRIPT
      ? { py: process.env.TDX_FLOW_PYEXE, script: process.env.TDX_FLOW_SCRIPT }
      : null;
  if (isWin) {
    return [
      env,
      { py: joinFromApp("..", "bridge", "python", "python.exe"), script: joinFromApp("..", "bridge", "tdx_flow_server.py") },
      { py: joinFromApp("..", "..", "bridge", "python", "python.exe"), script: joinFromApp("..", "..", "bridge", "tdx_flow_server.py") },
      // 绿色版约定：bridge 与 resources 同级，位于安装目录根部
      { py: joinFromApp("..", "..", "..", "bridge", "python", "python.exe"), script: joinFromApp("..", "..", "..", "bridge", "tdx_flow_server.py") },
      { py: joinFromApp("..", "tools", ".venv", "Scripts", "python.exe"), script: joinFromApp("..", "tools", "tdx_flow_server.py") },
      { py: joinFromApp("..", "..", "tools", ".venv", "Scripts", "python.exe"), script: joinFromApp("..", "..", "tools", "tdx_flow_server.py") },
      { py: joinFromApp("..", "..", "..", "tools", ".venv", "Scripts", "python.exe"), script: joinFromApp("..", "..", "..", "tools", "tdx_flow_server.py") },
    ].filter(Boolean);
  }
  // 开发=<项目>/electron；打包=<App>.app/Contents/Resources/app/electron
  // 再往上两级是 .app 旁（用户把 bridge 放在安装目录时）
  return [
    env,
    { py: joinFromApp("..", "bridge", "python", "bin", "python3"), script: joinFromApp("..", "bridge", "tdx_flow_server.py") },
    { py: joinFromApp("..", "..", "bridge", "python", "bin", "python3"), script: joinFromApp("..", "..", "bridge", "tdx_flow_server.py") },
    { py: joinFromApp("..", "..", "..", "bridge", "python", "bin", "python3"), script: joinFromApp("..", "..", "..", "bridge", "tdx_flow_server.py") },
    { py: joinFromApp("..", "..", "..", "..", "bridge", "python", "bin", "python3"), script: joinFromApp("..", "..", "..", "..", "bridge", "tdx_flow_server.py") },
    { py: joinFromApp("..", "tools", ".venv", "bin", "python3"), script: joinFromApp("..", "tools", "tdx_flow_server.py") },
    { py: joinFromApp("..", "..", "tools", ".venv", "bin", "python3"), script: joinFromApp("..", "..", "tools", "tdx_flow_server.py") },
    { py: joinFromApp("..", "..", "..", "tools", ".venv", "bin", "python3"), script: joinFromApp("..", "..", "..", "tools", "tdx_flow_server.py") },
    { py: joinFromApp("..", "..", "..", "..", "tools", ".venv", "bin", "python3"), script: joinFromApp("..", "..", "..", "..", "tools", "tdx_flow_server.py") },
  ].filter(Boolean);
}

function normalizePath(value) {
  return String(value || "")
    .replace(/"/g, "")
    .replace(/\\/g, "/")
    .replace(/\/+$/, "")
    .toLowerCase();
}

function readWindowsProcesses() {
  if (!isWin) return Promise.resolve([]);
  const script =
    "$ErrorActionPreference='SilentlyContinue'; " +
    "Get-CimInstance Win32_Process | Select-Object ProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress";
  return new Promise((resolve) => {
    let settled = false;
    let child = null;
    const finish = (rows) => {
      if (settled) return;
      settled = true;
      resolve(rows);
    };
    const timer = setTimeout(() => {
      try {
        if (child) child.kill();
      } catch {
        /* ignore */
      }
      finish([]);
    }, 3000);
    try {
      child = execFile(
        "powershell.exe",
        ["-NoProfile", "-NonInteractive", "-Command", script],
        { windowsHide: true, maxBuffer: 4 * 1024 * 1024 },
        (err, stdout) => {
          clearTimeout(timer);
          if (err || !stdout) return finish([]);
          try {
            const parsed = JSON.parse(String(stdout));
            finish(Array.isArray(parsed) ? parsed : parsed ? [parsed] : []);
          } catch {
            finish([]);
          }
        }
      );
    } catch {
      clearTimeout(timer);
      finish([]);
    }
  });
}

function readUnixProcesses() {
  if (isWin) return Promise.resolve([]);
  return new Promise((resolve) => {
    let settled = false;
    let child = null;
    const finish = (rows) => {
      if (settled) return;
      settled = true;
      resolve(rows);
    };
    const timer = setTimeout(() => {
      try {
        if (child) child.kill();
      } catch {
        /* ignore */
      }
      finish([]);
    }, 3000);
    try {
      child = execFile("ps", ["-ax", "-o", "pid=,command="], { maxBuffer: 4 * 1024 * 1024 }, (err, stdout) => {
        clearTimeout(timer);
        if (err || !stdout) return finish([]);
        const rows = [];
        for (const line of String(stdout).split(/\n/)) {
          const m = line.trim().match(/^(\d+)\s+(.+)$/);
          if (!m) continue;
          rows.push({ ProcessId: Number(m[1]), CommandLine: m[2], ExecutablePath: m[2].split(/\s+/)[0] || "" });
        }
        finish(rows);
      });
    } catch {
      clearTimeout(timer);
      finish([]);
    }
  });
}

function readListeningPids(port) {
  if (!isWin) {
    return new Promise((resolve) => {
      let settled = false;
      let child = null;
      const finish = (pids) => {
        if (settled) return;
        settled = true;
        resolve(pids);
      };
      const timer = setTimeout(() => {
        try {
          if (child) child.kill();
        } catch {
          /* ignore */
        }
        finish([]);
      }, 1200);
      try {
        child = execFile("lsof", ["-nP", `-iTCP:${port}`, "-sTCP:LISTEN", "-t"], { maxBuffer: 256 * 1024 }, (err, stdout) => {
          clearTimeout(timer);
          if (err || !stdout) return finish([]);
          const pids = [];
          for (const tok of String(stdout).split(/\s+/)) {
            const pid = Number(tok);
            if (pid > 0 && !pids.includes(pid)) pids.push(pid);
          }
          finish(pids);
        });
      } catch {
        clearTimeout(timer);
        finish([]);
      }
    });
  }
  return new Promise((resolve) => {
    let settled = false;
    let child = null;
    const finish = (pids) => {
      if (settled) return;
      settled = true;
      resolve(pids);
    };
    const timer = setTimeout(() => {
      try {
        if (child) child.kill();
      } catch {
        /* ignore */
      }
      finish([]);
    }, 1200);
    try {
      child = execFile("netstat.exe", ["-ano", "-p", "tcp"], { windowsHide: true, maxBuffer: 512 * 1024 }, (err, stdout) => {
        clearTimeout(timer);
        if (err || !stdout) return finish([]);
        const wanted = `:${String(port)}`;
        const pids = [];
        for (const line of String(stdout).split(/\r?\n/)) {
          const fields = line.trim().split(/\s+/);
          if (fields.length < 5 || fields[0].toUpperCase() !== "TCP") continue;
          const local = fields[1];
          const state = fields[3].toUpperCase();
          const pid = Number(fields[4]);
          if (state === "LISTENING" && local.endsWith(wanted) && pid > 0 && !pids.includes(pid)) pids.push(pid);
        }
        finish(pids);
      });
    } catch {
      clearTimeout(timer);
      finish([]);
    }
  });
}

async function findBridgePids(candidates) {
  const executablePaths = new Set(candidates.map((c) => normalizePath(c.py)).filter(Boolean));
  const scriptPaths = candidates.map((c) => normalizePath(c.script)).filter(Boolean);
  const rows = isWin ? await readWindowsProcesses() : await readUnixProcesses();
  const matched = rows
    .filter((row) => {
      const pid = Number(row && row.ProcessId);
      if (!pid || pid === process.pid) return false;
      const exe = normalizePath(row.ExecutablePath);
      const command = normalizePath(row.CommandLine);
      return executablePaths.has(exe) || scriptPaths.some((script) => command.includes(script));
    })
    .map((row) => Number(row.ProcessId))
    .filter((pid, index, all) => pid > 0 && all.indexOf(pid) === index);
  if (matched.length > 0) return matched;
  // 8899 可能被用户自行启动或其他程序占用：禁止按端口兜底误杀
  return [];
}

function killBridgePid(pid) {
  if (!pid || pid === process.pid) return Promise.resolve();
  if (!isWin) {
    try {
      process.kill(pid, "SIGTERM");
    } catch {
      /* already gone */
    }
    return wait(250).then(() => {
      try {
        process.kill(pid, "SIGKILL");
      } catch {
        /* already gone */
      }
    });
  }
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      resolve();
    };
    const timer = setTimeout(finish, 2500);
    try {
      const killer = spawn("taskkill", ["/pid", String(pid), "/t", "/f"], {
        stdio: "ignore",
        windowsHide: true,
      });
      killer.once("error", () => {
        clearTimeout(timer);
        finish();
      });
      killer.once("close", () => {
        clearTimeout(timer);
        finish();
      });
    } catch {
      clearTimeout(timer);
      finish();
    }
  });
}

/** 结束当前安装目录下的桥接进程，即使它是旧版本或外部启动的，也不能留下文件锁。 */
async function stopFlowBridge() {
  if (bridgeStopPromise) return bridgeStopPromise;
  bridgeStopPromise = (async () => {
    const candidates = bridgeCandidates();
    const pids = new Set(trackedBridgePids);
    if (flowBridge && flowBridge.pid) pids.add(flowBridge.pid);
    for (const pid of await findBridgePids(candidates)) pids.add(pid);
    flowBridge = null;
    trackedBridgePids.clear();
    await Promise.all([...pids].map((pid) => killBridgePid(pid)));
    if (pids.size > 0) {
      const deadline = Date.now() + 1200;
      while (Date.now() < deadline) {
        const left = await findBridgePids(candidates);
        if (left.length === 0) break;
        await wait(100);
      }
    }
  })().catch(() => {
    /* bridge cleanup must never prevent the desktop app from closing */
  });
  return bridgeStopPromise;
}

/** 通达信分笔资金流桥接：8899 空闲且存在 python 时静默拉起；退出时必须杀掉，避免锁住安装目录 */
async function startFlowBridgeImpl() {
  const candidates = bridgeCandidates();
  if (await isLocalPortOpen(8899)) {
    // 旧版本可能已经启动了同一安装目录的桥接，记录其 PID，退出时一并回收。
    for (const pid of await findBridgePids(candidates)) trackedBridgePids.add(pid);
    return;
  }
  if (shutdownStarted) return;
  for (const c of candidates) {
    if (!fs.existsSync(c.py) || !fs.existsSync(c.script)) continue;
    try {
      const child = spawn(c.py, [c.script], {
        stdio: "ignore",
        windowsHide: true,
        cwd: os.tmpdir(),
      });
      child.on("error", () => {});
      child.on("exit", () => {
        if (child.pid) trackedBridgePids.delete(child.pid);
        if (flowBridge === child) flowBridge = null;
      });
      flowBridge = child;
      if (child.pid) trackedBridgePids.add(child.pid);
    } catch {
      /* 桥接启动失败不影响主程序 */
    }
    return;
  }
}

function startFlowBridge() {
  if (!bridgeStartPromise) {
    bridgeStartPromise = startFlowBridgeImpl().catch(() => {
      /* 桥接启动失败不影响主程序 */
    });
  }
  return bridgeStartPromise;
}

function setupMacMenu() {
  if (!isMac) return;
  app.setName("龙抬头盯盘大师");
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      {
        label: app.name,
        submenu: [
          { role: "about" },
          { type: "separator" },
          { role: "hide" },
          { role: "hideOthers" },
          { role: "unhide" },
          { type: "separator" },
          { role: "quit" },
        ],
      },
      { role: "editMenu" },
      { role: "windowMenu" },
    ])
  );
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1680,
    height: 1000,
    minWidth: 1366,
    minHeight: 800,
    show: false,
    backgroundColor: "#0b0e14",
    autoHideMenuBar: true,
    title: "龙抬头·专业盯盘分析终端",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false, // 本地桌面软件直连行情/竞价接口（file:// 页面访问 https 数据接口需要）
    },
  });
  win.once("ready-to-show", () => {
    win.maximize();
    win.show();
  });
  // 外链一律交给系统浏览器
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
  win.loadFile(path.join(__dirname, "../dist/index.html"));
}

app.whenReady().then(() => {
  setupMacMenu();
  if (initUpdater()) return;
  void startFlowBridge();
  // 兜底：对数据接口请求不发送/不校验 Origin，避免个别网关按 Origin 拒绝
  session.defaultSession.webRequest.onBeforeSendHeaders((details, callback) => {
    const h = details.requestHeaders;
    if (/gtimg\.cn|eastmoney\.com|qq\.com|aicubes\.cn|sina\.com\.cn/.test(details.url)) delete h["Origin"];
    callback({ requestHeaders: h });
  });
  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("before-quit", (event) => {
  if (shutdownStarted) {
    if (!shutdownDone) event.preventDefault();
    return;
  }
  shutdownStarted = true;
  event.preventDefault();
  Promise.resolve(bridgeStartPromise)
    .catch(() => {})
    .then(() => stopFlowBridge())
    .finally(() => {
      shutdownDone = true;
      app.exit(0);
    });
});

app.on("window-all-closed", () => {
  if (!shutdownStarted) app.quit();
});
